import { useState } from "react";
import { useParseXml, useSubmitFlag } from "@workspace/api-client-react";
import { CheckCircle2, ChevronDown, ChevronUp, Terminal } from "lucide-react";
import { useSession } from "../hooks/use-session";

interface ChallengeCardProps {
  flagNumber: number;
  title: string;
  description: string;
  hint: string;
  isCompleted: boolean;
  onComplete?: () => void;
  isManualSubmit?: boolean;
  solution?: string;
}

export default function ChallengeCard({
  flagNumber,
  title,
  description,
  hint,
  isCompleted,
  onComplete,
  isManualSubmit = false,
  solution,
}: ChallengeCardProps) {
  const { sessionId } = useSession();
  const [xml, setXml] = useState('<?xml version="1.0" encoding="UTF-8"?>\n<data></data>');
  const [manualFlag, setManualFlag] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [output, setOutput] = useState<string | null>(null);
  const [submitMsg, setSubmitMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const parseXml = useParseXml();
  const submitFlag = useSubmitFlag();

  const handleParse = () => {
    if (!sessionId || !xml.trim()) return;
    setOutput(null);

    parseXml.mutate(
      { data: { sessionId, flagNumber, xml } },
      {
        onSuccess: (data) => {
          setOutput(data.output || data.error || "Nəticə yoxdur");
          if (data.flagFound) onComplete?.();
        },
        onError: () => setOutput("Bağlantı xətası baş verdi."),
      }
    );
  };

  const handleManualSubmit = () => {
    if (!sessionId || !manualFlag.trim()) return;
    setSubmitMsg(null);

    submitFlag.mutate(
      { data: { sessionId, flagNumber, answer: manualFlag } },
      {
        onSuccess: (data) => {
          setSubmitMsg({ ok: data.correct, text: data.message });
          if (data.correct) onComplete?.();
        },
      }
    );
  };

  const borderColor = isCompleted ? "border-green-500/40" : "border-red-500/30";
  const headerColor = isCompleted ? "text-green-400" : "text-red-400";

  return (
    <div
      className={`border ${borderColor} bg-black relative transition-all`}
      style={isCompleted ? { boxShadow: "0 0 20px rgba(74,222,128,0.05)" } : {}}
      {...(solution ? { "data-solution": solution } : {})}
    >
      <div className="px-5 py-4 border-b border-white/5 flex items-start justify-between gap-4">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-mono tracking-widest ${headerColor}`}>
              FLAG_{String(flagNumber).padStart(2, "0")}
            </span>
            {isCompleted && (
              <span className="flex items-center gap-1 text-green-400 text-xs border border-green-500/30 px-2 py-0.5 bg-green-500/5">
                <CheckCircle2 className="w-3 h-3" />
                TAMAMLANDI
              </span>
            )}
          </div>
          <h3 className="text-white/90 font-mono font-semibold">{title}</h3>
          <p className="text-white/40 text-sm leading-relaxed">{description}</p>
        </div>
        <div className={`text-2xl font-bold font-mono shrink-0 ${isCompleted ? "text-green-500/20" : "text-red-500/15"}`}>
          {String(flagNumber).padStart(2, "0")}
        </div>
      </div>

      <div className="p-5 space-y-4">
        {!isManualSubmit ? (
          <>
            <div className="space-y-2">
              <div className="text-green-500/40 text-xs font-mono tracking-wider">XML PAYLOAD</div>
              <textarea
                value={xml}
                onChange={(e) => setXml(e.target.value)}
                className="w-full h-28 bg-black/60 border border-white/10 text-green-300 text-sm font-mono p-3 focus:outline-none focus:border-green-500/40 resize-none placeholder:text-white/20 transition-all"
                disabled={isCompleted || parseXml.isPending}
                spellCheck={false}
                data-testid={`textarea-flag-${flagNumber}`}
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleParse}
                disabled={isCompleted || parseXml.isPending || !xml.trim()}
                className={`flex-1 py-2 text-sm font-mono tracking-wider border transition-all ${
                  isCompleted
                    ? "border-green-500/40 text-green-400 bg-green-500/5 cursor-default"
                    : "border-red-500/40 text-red-400 hover:bg-red-500/10 disabled:opacity-30"
                }`}
                data-testid={`button-submit-${flagNumber}`}
              >
                {isCompleted ? "TAMAMLANDI ✓" : parseXml.isPending ? "Yoxlanılır..." : "Yoxla"}
              </button>
              <button
                onClick={() => setShowHint(!showHint)}
                className="px-4 py-2 text-sm font-mono border border-white/10 text-white/40 hover:border-white/20 hover:text-white/60 transition-all"
                title="İpucu"
                data-testid={`button-hint-${flagNumber}`}
              >
                {showHint ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>

            {output && (
              <div className="bg-black border border-white/10 p-4">
                <div className="flex items-center gap-2 text-green-500/40 text-xs font-mono mb-2">
                  <Terminal className="w-3 h-3" />
                  <span>PARSER OUTPUT</span>
                </div>
                <pre className="text-green-300/80 text-sm font-mono whitespace-pre-wrap leading-relaxed">
                  {output}
                </pre>
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="text-green-500/40 text-xs font-mono tracking-wider">FLAG SUBMIT</div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-green-500/30 text-xs font-mono">{">"}</span>
                  <input
                    type="text"
                    value={manualFlag}
                    onChange={(e) => setManualFlag(e.target.value)}
                    className="w-full bg-black border border-white/10 text-green-300 pl-7 pr-4 py-2 text-sm font-mono focus:outline-none focus:border-green-500/40 placeholder:text-white/20 transition-all"
                    placeholder="FLAG{...}"
                    disabled={isCompleted || submitFlag.isPending}
                    data-testid={`input-flag-${flagNumber}`}
                  />
                </div>
                <button
                  onClick={handleManualSubmit}
                  disabled={isCompleted || submitFlag.isPending || !manualFlag.trim()}
                  className={`px-5 py-2 text-sm font-mono border transition-all ${
                    isCompleted
                      ? "border-green-500/40 text-green-400 bg-green-500/5"
                      : "border-red-500/40 text-red-400 hover:bg-red-500/10 disabled:opacity-30"
                  }`}
                  data-testid={`button-submit-flag-${flagNumber}`}
                >
                  {isCompleted ? "✓" : submitFlag.isPending ? "..." : "Yoxla"}
                </button>
                <button
                  onClick={() => setShowHint(!showHint)}
                  className="px-3 py-2 text-sm font-mono border border-white/10 text-white/40 hover:border-white/20 transition-all"
                  data-testid={`button-hint-${flagNumber}`}
                >
                  {showHint ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>

              {submitMsg && (
                <div className={`text-xs font-mono px-3 py-2 border ${
                  submitMsg.ok
                    ? "text-green-400 border-green-500/30 bg-green-500/5"
                    : "text-red-400 border-red-500/30 bg-red-500/5"
                }`}>
                  {submitMsg.ok ? "✓ " : "✗ "}{submitMsg.text}
                </div>
              )}
            </div>
          </div>
        )}

        {showHint && (
          <div className="bg-yellow-500/5 border border-yellow-500/20 p-4">
            <span className="text-yellow-400/60 text-xs font-mono tracking-wider">HINT  </span>
            <span className="text-yellow-300/70 text-sm font-mono">{hint}</span>
          </div>
        )}
      </div>
    </div>
  );
}

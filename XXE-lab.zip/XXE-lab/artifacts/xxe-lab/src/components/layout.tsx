import React, { createContext, useContext, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";

export const TerminalLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-[100dvh] bg-background text-primary font-mono relative overflow-hidden flex flex-col terminal-flicker">
      <div className="terminal-scanline" />
      <div className="flex-1 w-full max-w-6xl mx-auto p-4 md:p-8 flex flex-col relative z-10">
        <header className="mb-8 border-b border-primary/30 pb-4 flex justify-between items-end gap-4">
          <div>
            <h1 className="text-2xl md:text-4xl font-bold glow-text">XXE_INJECTION_LAB</h1>
            <p className="text-xs text-primary/70 mt-1">SECURE_TERMINAL_V1.0</p>
          </div>
          <div className="text-right">
            <Link href="/admin" className="text-xs text-primary/50 hover:text-primary transition-colors">
              [ADMIN_ACCESS]
            </Link>
          </div>
        </header>
        
        <main className="flex-1 flex flex-col">
          {children}
        </main>
        
        <footer className="mt-12 border-t border-primary/30 pt-4 flex justify-between text-xs text-primary/50">
          <p>STATUS: ONLINE</p>
          <p>SYS_TIME: {new Date().toISOString()}</p>
        </footer>
      </div>
    </div>
  );
};

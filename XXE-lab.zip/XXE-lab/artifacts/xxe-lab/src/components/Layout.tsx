import { useState, useEffect } from "react";
import { useSession } from "../hooks/use-session";

interface LayoutProps {
  children: React.ReactNode;
  level: 1 | 2;
  completedFlags: number;
  totalFlags: number;
}

export default function Layout({ children, level, completedFlags, totalFlags }: LayoutProps) {
  const { userName } = useSession();
  const [timeLeft, setTimeLeft] = useState<string>("60:00");
  const [isExpiring, setIsExpiring] = useState(false);
  const progressPercent = Math.round((completedFlags / totalFlags) * 100);

  useEffect(() => {
    const timerStart = localStorage.getItem("xxe_timer_start");
    if (!timerStart) return;

    const start = parseInt(timerStart, 10);
    const totalMs = 60 * 60 * 1000;

    const interval = setInterval(() => {
      const remaining = Math.max(0, totalMs - (Date.now() - start));
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      setTimeLeft(`${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`);
      setIsExpiring(mins < 5);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#080c08] flex flex-col">
      <header className="border-b border-white/5 bg-[#080c08]/95 backdrop-blur sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">

          <div className="flex items-center gap-3 min-w-0">
            <div className="text-green-500/60 text-xs font-mono tracking-widest hidden sm:block">
              XXE<span className="text-white/20 mx-1">/</span>LAB
            </div>
            <div className="text-white/20 text-xs hidden sm:block">·</div>
            <span className="text-green-400/50 text-xs font-mono truncate">
              {userName && `[${userName}]`}
            </span>
          </div>

          <div className={`flex items-center gap-2 text-sm font-mono tabular-nums ${
            isExpiring ? "text-red-400" : "text-green-400/70"
          }`}>
            <span className="text-white/20 text-xs">⏱</span>
            <span style={isExpiring ? {textShadow: "0 0 8px rgba(248,113,113,0.5)"} : {}}>
              {timeLeft}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-white/30 text-xs font-mono hidden sm:block">
              LVL {level}
            </div>
            <div className="flex items-center gap-2">
              <div className="w-28 h-1 bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-green-500/60 transition-all duration-700"
                  style={{
                    width: `${progressPercent}%`,
                    boxShadow: progressPercent > 0 ? "0 0 6px rgba(74,222,128,0.4)" : "none"
                  }}
                />
              </div>
              <span className="text-green-400/50 text-xs font-mono whitespace-nowrap">
                {completedFlags}/{totalFlags}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {children}
      </main>
    </div>
  );
}

import { useEffect, useState } from "react";

interface SessionData {
  sessionId: number | null;
  userName: string | null;
}

export function useSession() {
  const [session, setSession] = useState<SessionData>({
    sessionId: null,
    userName: null,
  });
  
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const id = localStorage.getItem("xxe_session_id");
    const name = localStorage.getItem("xxe_user_name");
    
    if (id && name) {
      setSession({
        sessionId: parseInt(id, 10),
        userName: name,
      });
    }
    setIsLoaded(true);
  }, []);

  const login = (id: number, name: string) => {
    localStorage.setItem("xxe_session_id", id.toString());
    localStorage.setItem("xxe_user_name", name);
    setSession({ sessionId: id, userName: name });
  };

  const logout = () => {
    localStorage.removeItem("xxe_session_id");
    localStorage.removeItem("xxe_user_name");
    localStorage.removeItem("xxe_timer_start");
    setSession({ sessionId: null, userName: null });
  };

  return { ...session, isLoaded, login, logout };
}

import { useGetAdminUsers, getGetAdminUsersQueryKey } from "@workspace/api-client-react";

export default function Admin() {
  const { data: users, isLoading, refetch, isRefetching } = useGetAdminUsers({
    query: {
      queryKey: getGetAdminUsersQueryKey(),
      refetchInterval: 8000,
    },
  });

  const fmt = (iso: string) =>
    new Date(iso).toLocaleTimeString("az-AZ", { hour: "2-digit", minute: "2-digit" });

  const fmtTime = (s: number | null | undefined) => {
    if (!s) return "—";
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}d ${sec}s`;
  };

  return (
    <div className="min-h-screen bg-[#080c08] text-white/70 font-mono">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-8">

        <div className="flex items-end justify-between border-b border-white/5 pb-5">
          <div className="space-y-1">
            <div className="text-white/20 text-xs tracking-widest">ADMIN PANEL</div>
            <h1 className="text-xl font-semibold text-green-300/80"
              style={{ textShadow: "0 0 20px rgba(74,222,128,0.3)" }}>
              Tələbə Monitorinqi
            </h1>
            <p className="text-white/25 text-xs">Müəllim panelinə xoş gəldiniz</p>
          </div>
          <button
            onClick={() => refetch()}
            disabled={isRefetching}
            className="flex items-center gap-2 px-4 py-2 text-xs border border-white/10 text-white/40 hover:border-green-500/30 hover:text-green-400/60 transition-all disabled:opacity-30"
          >
            <span className={isRefetching ? "animate-spin inline-block" : ""}>↻</span>
            Yenilə
          </button>
        </div>

        {isLoading ? (
          <div className="text-center py-16 text-white/20 text-sm tracking-widest">
            Yüklənir...
          </div>
        ) : !users?.length ? (
          <div className="text-center py-16 space-y-2">
            <div className="text-white/15 text-4xl">∅</div>
            <p className="text-white/25 text-sm">Hələ heç bir tələbə qeydiyyatdan keçməyib.</p>
          </div>
        ) : (
          <div className="space-y-1">
            <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto_auto] gap-x-6 px-4 py-2 text-xs text-white/20 tracking-widest border-b border-white/5">
              <span>#</span>
              <span>AD SOYAD</span>
              <span>BAŞLAMA</span>
              <span>FLAGS</span>
              <span>XAL</span>
              <span>VAXT</span>
              <span>STATUS</span>
            </div>

            {users.map((user) => (
              <div
                key={user.id}
                className={`grid grid-cols-[auto_1fr_auto_auto_auto_auto_auto] gap-x-6 px-4 py-3 border-b border-white/5 text-sm hover:bg-white/[0.02] transition-colors ${
                  user.completed ? "border-l-2 border-l-green-500/30 pl-3" : ""
                }`}
                data-testid={`row-user-${user.id}`}
              >
                <span className="text-white/20">{user.id}</span>
                <span className={`font-medium truncate ${user.completed ? "text-green-300/80" : "text-white/60"}`}>
                  {user.name}
                </span>
                <span className="text-white/30 tabular-nums">{fmt(user.startedAt)}</span>
                <span className="text-white/50 tabular-nums">
                  <span className={user.flagCount > 0 ? "text-green-400/70" : ""}>{user.flagCount}</span>
                  <span className="text-white/20">/6</span>
                </span>
                <span className="text-white/40 tabular-nums">{user.score}</span>
                <span className="text-white/30 tabular-nums whitespace-nowrap">{fmtTime(user.elapsedSeconds)}</span>
                <span>
                  {user.completed ? (
                    <span className="text-green-400/70 text-xs">✓ bitdi</span>
                  ) : (
                    <span className="text-white/20 text-xs">davam edir</span>
                  )}
                </span>
              </div>
            ))}

            <div className="pt-4 flex gap-8 text-xs text-white/25">
              <span>Cəmi: <span className="text-white/50">{users.length}</span></span>
              <span>Tamamlayan: <span className="text-green-400/60">{users.filter(u => u.completed).length}</span></span>
              <span>Ort. flag: <span className="text-white/50">{users.length ? (users.reduce((a, u) => a + u.flagCount, 0) / users.length).toFixed(1) : 0}</span></span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { useEffect } from "react";
import { useLocation } from "wouter";
import { useGetFlagStatus, getGetFlagStatusQueryKey } from "@workspace/api-client-react";
import { useSession } from "../hooks/use-session";
import Layout from "../components/Layout";
import ChallengeCard from "../components/ChallengeCard";

const SOLUTIONS = {
  1: `<?xml version="1.0"?><!DOCTYPE data [<!ENTITY sirr "gizli_deger">]><data>&sirr;</data>`,
  2: `<?xml version="1.0"?><!DOCTYPE data [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><data>&xxe;</data>`,
  3: `<?xml version="1.0"?><data><![CDATA[<xss>test</xss>]]></data>`,
};

export default function Level1() {
  const [, setLocation] = useLocation();
  const { sessionId, isLoaded } = useSession();

  useEffect(() => {
    if (isLoaded && !sessionId) setLocation("/");
  }, [sessionId, isLoaded, setLocation]);

  const { data: flagStatus, refetch } = useGetFlagStatus(sessionId || 0, {
    query: {
      enabled: !!sessionId,
      queryKey: getGetFlagStatusQueryKey(sessionId || 0),
    },
  });

  if (!isLoaded || !sessionId) return null;

  const getStatus = (num: number) =>
    flagStatus?.flags?.find((f) => f.flagNumber === num)?.completed || false;

  const isLevelComplete = getStatus(1) && getStatus(2) && getStatus(3);

  return (
    <Layout level={1} completedFlags={flagStatus?.completed || 0} totalFlags={6}>
      <div className="space-y-8">

        <div className="space-y-1">
          <div className="text-white/20 text-xs font-mono tracking-widest">LEVEL 01 / BASICS</div>
          <h2 className="text-xl font-semibold text-green-300/80 font-mono">XXE Injection — Əsaslar</h2>
          <p className="text-white/35 text-sm font-mono leading-relaxed max-w-2xl">
            XML eXternal Entity (XXE) hücumu düzgün konfiqurasiya edilməmiş XML parserlərinə qarşı
            istifadə olunur. Entity-lər vasitəsilə daxili fayllara, şəbəkəyə giriş əldə etmək mümkün olur.
            Aşağıdakı 3 tapşırığı həll edin.
          </p>
        </div>

        <div className="space-y-4">
          <ChallengeCard
            flagNumber={1}
            title="Sadə Entity Expansion"
            description="XML entity mexanizmindən istifadə edərək gizli dəyəri açıqlayın."
            hint="F12 açın → Elements tabına keçin → bu elementi sağ klikləyin → Inspect edin → data-solution atributunda XML payload görünür."
            isCompleted={getStatus(1)}
            onComplete={refetch}
            solution={SOLUTIONS[1]}
          />
          <ChallengeCard
            flagNumber={2}
            title="External Entity"
            description="Xarici entity istifadə edərək SYSTEM direktivi ilə XXE hücumunu həyata keçirin."
            hint="F12 açın → Elements tabına keçin → bu elementi sağ klikləyin → Inspect edin → data-solution atributunda XML payload görünür."
            isCompleted={getStatus(2)}
            onComplete={refetch}
            solution={SOLUTIONS[2]}
          />
          <ChallengeCard
            flagNumber={3}
            title="XML Parsing Logic"
            description="CDATA section ilə xüsusi simvolları bypass edin."
            hint="F12 açın → Elements tabına keçin → bu elementi sağ klikləyin → Inspect edin → data-solution atributunda XML payload görünür."
            isCompleted={getStatus(3)}
            onComplete={refetch}
            solution={SOLUTIONS[3]}
          />
        </div>

        <div className="flex justify-end pt-4 border-t border-white/5">
          <button
            onClick={() => setLocation("/level2")}
            disabled={!isLevelComplete}
            className={`px-8 py-3 text-sm font-mono tracking-widest border transition-all ${
              isLevelComplete
                ? "border-green-500/50 text-green-400 hover:bg-green-500/10 cursor-pointer"
                : "border-white/10 text-white/20 cursor-not-allowed"
            }`}
            style={isLevelComplete ? { boxShadow: "0 0 20px rgba(74,222,128,0.1)" } : {}}
            data-testid="button-level2"
          >
            {isLevelComplete ? "LEVEL 2 →" : "LEVEL 2 [locked]"}
          </button>
        </div>
      </div>
    </Layout>
  );
}

import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useGetFlagStatus, getGetFlagStatusQueryKey } from "@workspace/api-client-react";
import { useSession } from "../hooks/use-session";

export default function Complete() {
  const [, setLocation] = useLocation();
  const { sessionId, userName, isLoaded, logout } = useSession();
  const [elapsed, setElapsed] = useState<string>("");

  useEffect(() => {
    if (isLoaded && !sessionId) setLocation("/");
  }, [isLoaded, sessionId, setLocation]);

  useEffect(() => {
    const start = localStorage.getItem("xxe_timer_start");
    if (!start) return;
    const secs = Math.floor((Date.now() - parseInt(start)) / 1000);
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    setElapsed(`${m} dəq ${s} san`);
  }, []);

  const { data: flagStatus } = useGetFlagStatus(sessionId || 0, {
    query: {
      enabled: !!sessionId,
      queryKey: getGetFlagStatusQueryKey(sessionId || 0),
    },
  });

  if (!isLoaded || !sessionId) return null;

  const completed = flagStatus?.completed || 0;
  const total = 6;
  const isPerfect = completed === total;

  const handleRestart = () => {
    logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-[#080c08] flex flex-col items-center justify-center px-6 py-12">
      <div className="w-full max-w-md space-y-10 text-center">

        <div className="space-y-2">
          <div className="text-white/20 text-xs font-mono tracking-widest">LAB TAMAMLANDI</div>
          <div
            className="text-6xl font-bold font-mono"
            style={{
              color: isPerfect ? "#4ade80" : "#a8d5a8",
              textShadow: isPerfect
                ? "0 0 40px rgba(74,222,128,0.5), 0 0 80px rgba(74,222,128,0.2)"
                : "0 0 20px rgba(74,222,128,0.2)",
            }}
          >
            {isPerfect ? "6/6" : `${completed}/6`}
          </div>
          <p className="text-white/40 text-sm font-mono">flag tapıldı</p>
        </div>

        <div className="border border-white/8 bg-white/[0.02] p-6 space-y-4 text-left">
          <div className="flex justify-between items-center text-sm">
            <span className="text-white/30 font-mono">Operator</span>
            <span className="text-green-300/70 font-mono">{userName}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-white/30 font-mono">Flags</span>
            <span className="text-white/60 font-mono">{completed} / {total}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-white/30 font-mono">Xal</span>
            <span className="text-white/60 font-mono">{completed * 100}</span>
          </div>
          {elapsed && (
            <div className="flex justify-between items-center text-sm">
              <span className="text-white/30 font-mono">Sərf olunan vaxt</span>
              <span className="text-white/60 font-mono">{elapsed}</span>
            </div>
          )}

          <div className="border-t border-white/5 pt-4 grid grid-cols-6 gap-1">
            {Array.from({ length: total }, (_, i) => {
              const done = flagStatus?.flags?.find(f => f.flagNumber === i + 1)?.completed;
              return (
                <div
                  key={i}
                  className="aspect-square flex items-center justify-center text-xs font-mono border"
                  style={{
                    borderColor: done ? "rgba(74,222,128,0.4)" : "rgba(255,255,255,0.06)",
                    backgroundColor: done ? "rgba(74,222,128,0.05)" : "transparent",
                    color: done ? "#4ade80" : "rgba(255,255,255,0.15)",
                  }}
                  title={`Flag ${i + 1}`}
                >
                  {done ? "✓" : i + 1}
                </div>
              );
            })}
          </div>
        </div>

        <div className="space-y-3">
          {isPerfect ? (
            <p className="text-green-400/50 text-sm font-mono leading-relaxed">
              Bütün flagları tapdınız. Əla iş, {userName}!
            </p>
          ) : (
            <p className="text-white/25 text-sm font-mono leading-relaxed">
              {total - completed} flag tapılmamış qaldı. Növbəti dəfə daha yaxşı olar.
            </p>
          )}

          <button
            onClick={handleRestart}
            className="w-full py-3 text-sm font-mono tracking-widest border border-white/10 text-white/35 hover:border-green-500/30 hover:text-green-400/50 transition-all"
            data-testid="button-restart"
          >
            Yenidən başla
          </button>
        </div>
      </div>
    </div>
  );
}

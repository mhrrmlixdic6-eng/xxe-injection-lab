import { useEffect } from "react";
import { useLocation } from "wouter";
import { useGetFlagStatus, getGetFlagStatusQueryKey } from "@workspace/api-client-react";
import { useSession } from "../hooks/use-session";
import Layout from "../components/Layout";
import ChallengeCard from "../components/ChallengeCard";

export default function Level2() {
  const [, setLocation] = useLocation();
  const { sessionId, isLoaded } = useSession();

  useEffect(() => {
    if (isLoaded && !sessionId) setLocation("/");
  }, [sessionId, isLoaded, setLocation]);

  const { data: flagStatus, refetch } = useGetFlagStatus(sessionId || 0, {
    query: {
      enabled: !!sessionId,
      queryKey: getGetFlagStatusQueryKey(sessionId || 0),
    },
  });

  if (!isLoaded || !sessionId) return null;

  const getStatus = (num: number) =>
    flagStatus?.flags?.find((f) => f.flagNumber === num)?.completed || false;

  const isLevelComplete = getStatus(4) && getStatus(5) && getStatus(6);

  return (
    <Layout level={2} completedFlags={flagStatus?.completed || 0} totalFlags={6}>
      <div className="space-y-8">

        <div className="space-y-1">
          <div className="text-white/20 text-xs font-mono tracking-widest">LEVEL 02 / ADVANCED</div>
          <h2 className="text-xl font-semibold text-red-300/70 font-mono">XXE Advanced Bypasses</h2>
          <p className="text-white/35 text-sm font-mono leading-relaxed max-w-2xl">
            Bəzən sadə payload-lar WAF (Web Application Firewall) və ya kod
            səviyyəsindəki filtrlər tərəfindən bloklanır. Bu mərhələdə real
            dünyadakı bypass texnikalarını tətbiq edin. İpucu minimumdur.
          </p>
        </div>

        <div className="space-y-4">
          <ChallengeCard
            flagNumber={4}
            title="Filter Bypass"
            description='Sistem "xxe" sözünü avtomatik silir. Filteri bypass edin.'
            hint='Bəzən bir şeyin içinə başqa bir şey gizlətmək olar... "xXXExe" sınayın.'
            isCompleted={getStatus(4)}
            onComplete={refetch}
          />
          <ChallengeCard
            flagNumber={5}
            title="IP Bypass"
            description="127.0.0.1 bloklanıb. Alternativ IP representasiyası istifadə edin."
            hint="Eyni ünvan fərqli görünə bilər. (0x7f000001 və ya 2130706433)"
            isCompleted={getStatus(5)}
            onComplete={refetch}
          />
          <ChallengeCard
            flagNumber={6}
            title="Route Discovery"
            description="Gizli API route-u tapın və oradan əldə etdiyiniz flag-ı daxil edin."
            hint="API routing davranışını araşdırın. /api/ ilə başlayan gizli endpoint var."
            isCompleted={getStatus(6)}
            onComplete={refetch}
            isManualSubmit={true}
          />
        </div>

        <div className="flex justify-end pt-4 border-t border-white/5">
          <button
            onClick={() => setLocation("/complete")}
            className={`px-8 py-3 text-sm font-mono tracking-widest border transition-all ${
              isLevelComplete
                ? "border-green-500/50 text-green-400 hover:bg-green-500/10"
                : "border-red-500/30 text-red-400/60 hover:bg-red-500/5"
            }`}
            data-testid="button-complete"
          >
            {isLevelComplete ? "LAB TAMAMLANDI →" : "Laboratoriyanı bitir"}
          </button>
        </div>
      </div>
    </Layout>
  );
}

import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#080c08] font-mono px-6">
      <div className="text-center space-y-6">
        <div className="text-red-500/20 text-8xl font-bold">404</div>
        <div className="space-y-2">
          <p className="text-red-400/60 text-sm tracking-widest uppercase">Səhifə tapılmadı</p>
          <p className="text-white/25 text-xs">Axtardığınız route mövcud deyil.</p>
        </div>
        <Link href="/">
          <span className="inline-block mt-2 px-6 py-2 text-xs font-mono border border-white/10 text-white/35 hover:border-green-500/30 hover:text-green-400/50 transition-all cursor-pointer">
            Ana səhifəyə qayıt
          </span>
        </Link>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useCreateSession } from "@workspace/api-client-react";
import { useSession } from "../hooks/use-session";

export default function Home() {
  const [, setLocation] = useLocation();
  const { sessionId, isLoaded, login } = useSession();
  const [name, setName] = useState("");
  const createSession = useCreateSession();

  useEffect(() => {
    if (isLoaded && sessionId) {
      setLocation("/level1");
    }
  }, [isLoaded, sessionId, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    createSession.mutate(
      { data: { name } },
      {
        onSuccess: (session) => {
          login(session.id, session.name);
          localStorage.setItem("xxe_timer_start", Date.now().toString());
          setLocation("/level1");
        },
      }
    );
  };

  if (!isLoaded) return <div className="min-h-screen bg-black" />;

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-black p-6">
      <div className="w-full max-w-sm space-y-10">

        <div className="text-center space-y-3">
          <div className="text-green-500/40 text-sm tracking-[0.3em] uppercase mb-6">
            Cybersecurity Lab
          </div>
          <h1 className="text-5xl font-bold text-green-400 tracking-widest uppercase" style={{textShadow: "0 0 30px rgba(74,222,128,0.5), 0 0 60px rgba(74,222,128,0.2)"}}>
            XXE
          </h1>
          <h2 className="text-xl text-green-300/80 tracking-[0.2em] uppercase font-light">
            Injection Lab
          </h2>
          <p className="text-green-500/40 text-xs tracking-widest mt-2">
            Interactive Security Laboratory
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-green-500/60 text-xs tracking-widest uppercase">
              Operator ID
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-green-500/50 text-sm font-mono">$</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-black border border-green-500/30 text-green-300 pl-8 pr-4 py-3 text-sm font-mono focus:outline-none focus:border-green-400 focus:shadow-[0_0_15px_rgba(74,222,128,0.15)] placeholder:text-green-500/20 transition-all"
                placeholder="Ad və soyad daxil edin"
                autoFocus
                disabled={createSession.isPending}
                data-testid="input-name"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={createSession.isPending || !name.trim()}
            className="w-full py-3 text-sm font-mono tracking-widest uppercase border border-green-500/50 text-green-400 bg-transparent hover:bg-green-500/10 hover:border-green-400 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            style={name.trim() ? {boxShadow: "0 0 20px rgba(74,222,128,0.1)"} : {}}
            data-testid="button-start"
          >
            {createSession.isPending ? "[ Yüklənir... ]" : "[ Başla ]"}
          </button>
        </form>

        <div className="text-center text-green-500/20 text-xs tracking-widest">
          ── 6 flag · 2 level · 60 dəq ──
        </div>
      </div>
    </div>
  );
}

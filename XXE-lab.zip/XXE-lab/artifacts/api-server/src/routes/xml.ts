import { Router, type IRouter } from "express";
import { db, flagCapturesTable, labSessionsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { ParseXmlBody } from "@workspace/api-zod";

const router: IRouter = Router();

const FLAGS: Record<number, string> = {
  1: "FLAG{xxe_l1_entity_expansion_1337}",
  2: "FLAG{xxe_l1_external_entity_1337}",
  3: "FLAG{xxe_l1_xml_logic_1337}",
  4: "FLAG{xxe_l2_filter_bypass_1337}",
  5: "FLAG{xxe_l2_ip_bypass_1337}",
};

function checkFlag1(xml: string): { found: boolean; output: string } {
  const hasEntity = /<!ENTITY\s+\w+\s+"[^"]*"/.test(xml) || /<!ENTITY\s+\w+\s+'[^']*'/.test(xml);
  const hasRef = /&\w+;/.test(xml);
  if (hasEntity && hasRef) {
    const match = xml.match(/<!ENTITY\s+(\w+)\s+["']([^"']*)["']/);
    if (match) {
      const entityName = match[1];
      const entityValue = match[2];
      return {
        found: true,
        output: `XML Entity Expansion Nəticəsi:\n&${entityName}; → "${entityValue}"\n\nEntity uğurla genişləndirildi!`,
      };
    }
  }
  return {
    found: false,
    output: hasEntity
      ? "Entity təyin edildi lakin referans tapılmadı. &entityAdi; formasında istifadə edin."
      : "XML entity təyinatı tapılmadı. <!ENTITY> sintaksisini istifadə edin.",
  };
}

function checkFlag2(xml: string): { found: boolean; output: string } {
  const hasSystem = /<!ENTITY[^>]+SYSTEM/i.test(xml);
  if (hasSystem) {
    return {
      found: true,
      output: "External entity aşkarlandı! SYSTEM directive istifadə etdiniz.\nXXE attack vektoru aktiv edildi.",
    };
  }
  return {
    found: false,
    output: "External entity tapılmadı. SYSTEM keyword ilə xarici fayl yükləməyi sınayın.",
  };
}

function checkFlag3(xml: string): { found: boolean; output: string } {
  const hasCdata = /<!\[CDATA\[/.test(xml);
  if (hasCdata) {
    return {
      found: true,
      output: "CDATA section aşkarlandı! XML parsing bypass uğurlu oldu.",
    };
  }
  const hasNestedData = /<data[^>]*>.*<data[^>]*>/is.test(xml);
  if (hasNestedData) {
    return {
      found: true,
      output: "İç-içə XML strukturu aşkarlandı! Parsing logic bypass uğurlu oldu.",
    };
  }
  return {
    found: false,
    output: "XML parsing challenge tamamlanmadı. CDATA section və ya xüsusi XML strukturu istifadə edin.",
  };
}

function checkFlag4(xml: string): { found: boolean; output: string; filtered: string } {
  const filtered = xml.replace(/xxe/gi, "");
  const hasXxeAfterFilter = /xxe/i.test(filtered);
  if (hasXxeAfterFilter) {
    return {
      found: true,
      output: `Filter tətbiq edildi.\nOriginal: ${xml.substring(0, 100)}\nFilter sonrası: ${filtered.substring(0, 100)}\n\nFilter bypass uğurlu! "xxe" hələ də qalır.`,
      filtered,
    };
  }
  if (/xxe/i.test(xml)) {
    return {
      found: false,
      output: `Filter tətbiq edildi. "xxe" sözü silindi.\nFilter sonrası: ${filtered.substring(0, 200)}\n\nFilter bypass edin: xxe sözünü içindən gizlədərək yenidən cəhd edin.`,
      filtered,
    };
  }
  return {
    found: false,
    output: `XML işləndi.\nFilter sonrası: ${filtered.substring(0, 200)}\n\n"xxe" müəyyən edilmədi.`,
    filtered,
  };
}

const ALT_IP_PATTERNS = [
  /0x7f000001/i,
  /2130706433/,
  /0177\.0\.0\.1/,
  /127\.0+\.0+\.0*1/,
  /\[::1\]/,
  /localhost/i,
  /0x7f\.0x00\.0x00\.0x01/i,
  /127\.1(?!\d)/,
];

function checkFlag5(xml: string): { found: boolean; output: string } {
  const hasDirectIp = /127\.0\.0\.1/.test(xml);
  const hasAltIp = ALT_IP_PATTERNS.some((p) => p.test(xml));
  if (hasDirectIp || hasAltIp) {
    return {
      found: true,
      output: hasAltIp && !hasDirectIp
        ? "Alternativ IP reprezentasiyası aşkarlandı! IP bypass uğurlu oldu."
        : "Loopback IP aşkarlandı! Flag tapıldı.",
    };
  }
  return {
    found: false,
    output: "IP ünvanı tapılmadı. XML içində 127.0.0.1 və ya onun ekvivalentini istifadə edin.",
  };
}

router.post("/xml/parse", async (req, res): Promise<void> => {
  const parsed = ParseXmlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { xml, sessionId, flagNumber } = parsed.data;

  const [session] = await db
    .select()
    .from(labSessionsTable)
    .where(eq(labSessionsTable.id, sessionId));

  if (!session) {
    res.status(404).json({ error: "Session tapılmadı" });
    return;
  }

  const alreadyCaptured = await db
    .select()
    .from(flagCapturesTable)
    .where(
      and(
        eq(flagCapturesTable.sessionId, sessionId),
        eq(flagCapturesTable.flagNumber, flagNumber)
      )
    );

  if (alreadyCaptured.length > 0) {
    const flagValue = FLAGS[flagNumber] ?? null;
    res.json({
      output: "Bu flag artıq əldə edilib!",
      success: true,
      flagFound: true,
      flag: flagValue,
      error: null,
    });
    return;
  }

  let result: { found: boolean; output: string };

  if (flagNumber === 1) {
    result = checkFlag1(xml);
  } else if (flagNumber === 2) {
    result = checkFlag2(xml);
  } else if (flagNumber === 3) {
    result = checkFlag3(xml);
  } else if (flagNumber === 4) {
    const r4 = checkFlag4(xml);
    result = { found: r4.found, output: r4.output };
  } else if (flagNumber === 5) {
    result = checkFlag5(xml);
  } else {
    res.status(400).json({ error: "Yanlış flag nömrəsi" });
    return;
  }

  if (result.found) {
    await db.insert(flagCapturesTable).values({ sessionId, flagNumber }).onConflictDoNothing();

    const totalCaptures = await db
      .select()
      .from(flagCapturesTable)
      .where(eq(flagCapturesTable.sessionId, sessionId));

    if (totalCaptures.length >= 6) {
      await db
        .update(labSessionsTable)
        .set({ completedAt: new Date() })
        .where(eq(labSessionsTable.id, sessionId));
    }

    res.json({
      output: result.output,
      success: true,
      flagFound: true,
      flag: FLAGS[flagNumber] ?? null,
      error: null,
    });
  } else {
    res.json({
      output: result.output,
      success: true,
      flagFound: false,
      flag: null,
      error: null,
    });
  }
});

export default router;

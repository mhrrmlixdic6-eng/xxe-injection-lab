import { Router, type IRouter } from "express";
import { db, labSessionsTable, flagCapturesTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/admin/users", async (_req, res): Promise<void> => {
  const sessions = await db.select().from(labSessionsTable).orderBy(labSessionsTable.startedAt);

  const result = await Promise.all(
    sessions.map(async (session) => {
      const captures = await db
        .select({ count: count() })
        .from(flagCapturesTable)
        .where(eq(flagCapturesTable.sessionId, session.id));

      const flagCount = Number(captures[0]?.count ?? 0);
      const completed = flagCount >= 6;

      let elapsedSeconds: number | null = null;
      if (session.completedAt) {
        elapsedSeconds = Math.floor(
          (session.completedAt.getTime() - session.startedAt.getTime()) / 1000
        );
      } else {
        elapsedSeconds = Math.floor(
          (Date.now() - session.startedAt.getTime()) / 1000
        );
      }

      const score = flagCount * 100 - (elapsedSeconds ? Math.floor(elapsedSeconds / 60) * 5 : 0);

      return {
        id: session.id,
        name: session.name,
        startedAt: session.startedAt.toISOString(),
        completedAt: session.completedAt ? session.completedAt.toISOString() : null,
        flagCount,
        completed,
        score: Math.max(0, score),
        elapsedSeconds,
      };
    })
  );

  res.json(result);
});

export default router;

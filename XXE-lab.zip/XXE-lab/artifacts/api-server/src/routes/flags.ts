import { Router, type IRouter } from "express";
import { db, flagCapturesTable, labSessionsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { GetFlagStatusParams, SubmitFlagBody } from "@workspace/api-zod";

const router: IRouter = Router();

const TOTAL_FLAGS = 6;

const CORRECT_ANSWERS: Record<number, string[]> = {
  6: ["FLAG{xxe_l2_route_discovery_1337}"],
};

router.get("/flags/status/:sessionId", async (req, res): Promise<void> => {
  const params = GetFlagStatusParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(labSessionsTable)
    .where(eq(labSessionsTable.id, params.data.sessionId));

  if (!session) {
    res.status(404).json({ error: "Session tapılmadı" });
    return;
  }

  const captures = await db
    .select()
    .from(flagCapturesTable)
    .where(eq(flagCapturesTable.sessionId, params.data.sessionId));

  const captureMap = new Map(captures.map((c) => [c.flagNumber, c]));

  const flags = Array.from({ length: TOTAL_FLAGS }, (_, i) => {
    const flagNumber = i + 1;
    const capture = captureMap.get(flagNumber);
    return {
      flagNumber,
      completed: !!capture,
      capturedAt: capture ? capture.capturedAt.toISOString() : null,
    };
  });

  res.json({
    flags,
    total: TOTAL_FLAGS,
    completed: captures.length,
  });
});

router.post("/flags/submit", async (req, res): Promise<void> => {
  const parsed = SubmitFlagBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { sessionId, flagNumber, answer } = parsed.data;

  const [session] = await db
    .select()
    .from(labSessionsTable)
    .where(eq(labSessionsTable.id, sessionId));

  if (!session) {
    res.status(404).json({ error: "Session tapılmadı" });
    return;
  }

  const validAnswers = CORRECT_ANSWERS[flagNumber];
  if (!validAnswers) {
    res.status(400).json({ error: "Bu flag üçün manual submit dəstəklənmir" });
    return;
  }

  const isCorrect = validAnswers.includes(answer.trim());

  if (isCorrect) {
    await db
      .insert(flagCapturesTable)
      .values({ sessionId, flagNumber })
      .onConflictDoNothing();

    const totalCaptures = await db
      .select()
      .from(flagCapturesTable)
      .where(eq(flagCapturesTable.sessionId, sessionId));

    if (totalCaptures.length >= 6) {
      await db
        .update(labSessionsTable)
        .set({ completedAt: new Date() })
        .where(eq(labSessionsTable.id, sessionId));
    }

    res.json({
      correct: true,
      flag: answer.trim(),
      message: "Doğrudur! Flag tapıldı.",
    });
  } else {
    res.json({
      correct: false,
      flag: null,
      message: "Yanlış cavab. Yenidən cəhd edin.",
    });
  }
});

export default router;

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import sessionRouter from "./session";
import xmlRouter from "./xml";
import flagsRouter from "./flags";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sessionRouter);
router.use(xmlRouter);
router.use(flagsRouter);
router.use(adminRouter);

export default router;

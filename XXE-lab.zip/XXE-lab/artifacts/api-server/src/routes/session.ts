import { Router, type IRouter } from "express";
import { db, labSessionsTable, flagCapturesTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import { CreateSessionBody, GetSessionParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/session", async (req, res): Promise<void> => {
  const parsed = CreateSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [session] = await db
    .insert(labSessionsTable)
    .values({ name: parsed.data.name })
    .returning();

  res.status(201).json({
    id: session.id,
    name: session.name,
    startedAt: session.startedAt.toISOString(),
    completedAt: session.completedAt ? session.completedAt.toISOString() : null,
    flagCount: 0,
  });
});

router.get("/session/:id", async (req, res): Promise<void> => {
  const params = GetSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(labSessionsTable)
    .where(eq(labSessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const captures = await db
    .select({ count: count() })
    .from(flagCapturesTable)
    .where(eq(flagCapturesTable.sessionId, session.id));

  const flagCount = Number(captures[0]?.count ?? 0);

  res.json({
    id: session.id,
    name: session.name,
    startedAt: session.startedAt.toISOString(),
    completedAt: session.completedAt ? session.completedAt.toISOString() : null,
    flagCount,
  });
});

router.get("/user", async (_req, res): Promise<void> => {
  res.json({
    flag: "FLAG{xxe_l2_route_discovery_1337}",
    message: "Gizli route tapıldı! Bu Flag 6-dır. Təbriklər!",
  });
});

export default router;
